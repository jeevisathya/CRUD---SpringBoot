package com.example.demo;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
//import javax.validation.Valid;

@RequestMapping("/api/v1")
@RestController
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping("/employees")
    public List<Employee> getAllEmployees() {
        System.out.println("Inside getAllEmployees method----");
        List<Employee> employeeList = employeeRepository.findAll();
        System.out.println("employeeList---->" + employeeList);
        return employeeList;
    }
    @GetMapping("/employees/{EMP_ID}")
     public ResponseEntity<Employee> getEmployeeByEmpId(@PathVariable(value = "EMP_ID") Long employeeEmpId)
            throws ResourceNotFoundException {
    Employee employee = employeeRepository.findById(employeeEmpId)
              .orElseThrow(() -> new ResourceNotFoundException("Employee not found for this employeeEmpId :: " + employeeEmpId));
    return ResponseEntity.ok().body(employee);
       }

    @PostMapping("/employees")
    public Employee createEmployee(@RequestBody Employee employee)
    {
        return employeeRepository.save(employee);
    }

    @PutMapping("/employees/{Emp_ID}")
    public ResponseEntity<Employee> updateEmployeeByEmpId(@PathVariable Long Emp_ID, @RequestBody Employee employee) {
        System.out.println("employeeEmpId : "+Emp_ID);
        Optional<Employee> Employeedetails = employeeRepository.findById(Emp_ID);
        if (Employeedetails.isPresent()) {
            Employee obj = Employeedetails.get();
            obj.setName(employee.getName());
            obj.setEmail(employee.getEmail());
            return new ResponseEntity<>(employeeRepository.save(obj), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


//    @PatchMapping("/employees/{Emp_ID}")
//    public ResponseEntity<Employee> updatepatchEmpID(@PathVariable Long Emp_ID, @RequestBody Employee employee) {
//        System.out.println("employeeEmpId : "+Emp_ID);
//        Optional<Employee> Employeedetails = employeeRepository.findById(Emp_ID);
//        if (Employeedetails.isPresent()) {
//            Employee obj = Employeedetails.get();
//            obj.setCountry(employee.getCountry());
//            obj.setCity(employee.getCity());
//            employee.setEmp_id(Emp_ID);
//            return new ResponseEntity<>(employeeRepository.save(employee), HttpStatus.OK);
//        } else {
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//        }
//    }


    @PatchMapping(value = "/employees/{Emp_ID}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Employee> updatepatchEmpID(@PathVariable Long Emp_ID, @RequestBody Map<String, Object>  employee) {
        System.out.println("employeeEmpId : "+Emp_ID);
        Optional<Employee> Employeedetails = employeeRepository.findById(Emp_ID);
        if (Employeedetails.isPresent()) {
            Employee obj = Employeedetails.get();
            obj.setCountry((String) employee.get("country"));
            obj.setCity((String) employee.get("city"));
            return new ResponseEntity<>(employeeRepository.save(obj), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

//    @PatchMapping
//    public ResponseEntity<Employee> patchInternApi(@PathVariable Long Emp_ID, @RequestBody Employee employee){
//
//        //RETRIEVE THE ASSOCIATED INTERN FROM DATABASE THROUGH ITS ID
//        Optional <Employee> Object=employeeRepository.findById(Emp_ID);
//
//        //UPDATE ONLY THOSE FIELDS WHICH ARE NOT NULL IN THE INCOMPLETE INTERN OBJECT
//        if(employee.getEmail()==null){
//            Employee obj = Object.get();
//            obj.setEmail(obj.getEmail());
//            return new ResponseEntity<>(employeeRepository.save(obj), HttpStatus.OK);
//        }else{
//            Employee obj = Object.get();
//            obj.setEmail(employee.getEmail());
//            return new ResponseEntity<>(employeeRepository.save(obj), HttpStatus.OK);
//        }
//    }

    @DeleteMapping("/employees/{EMP_ID}")
    public Map<String, Boolean> deleteEmployee(@PathVariable(value = "EMP_ID") Long employeeEmpId)
            throws ResourceNotFoundException {
        Employee employee = employeeRepository.findById(employeeEmpId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + employeeEmpId));

        employeeRepository.delete(employee);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }

}